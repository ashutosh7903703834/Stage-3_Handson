package com.cognizant.ormlearn.model;

public class Employee {

	public Employee() {
		// TODO Auto-generated constructor stub
	}

	public Object getDepartment() {
		// TODO Auto-generated method stub
		return null;
	}

}
