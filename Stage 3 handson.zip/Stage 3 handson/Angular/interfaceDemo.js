;
var person = {
    firstName: "Shashwat",
    lastName: "Tiwari",
    sayHi: function (firstName, lastName) { return ("Hello " + firstName + " " + lastName); }
};
console.log(person.firstName);
console.log(person.lastName);
console.log(person.sayHi("Shash", "wat"));
