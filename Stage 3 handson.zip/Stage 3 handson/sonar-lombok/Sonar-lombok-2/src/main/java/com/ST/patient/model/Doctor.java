package com.ST.patient.model;

public enum Doctor {
	Doc1, Doc2, Doc3

}
