package com.ST.flight.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class Passenger {

	private String name;
	private boolean vip;

	public Passenger() {
		// TODO Auto-generated constructor stub
	}

}
